#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Randall Balestriero"
# https://www.tensorflow.org/datasets/catalog/places365_small
