#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Randall Balestriero"
# https://ai.stanford.edu/%7Ejkrause/cars/car_dataset.html
